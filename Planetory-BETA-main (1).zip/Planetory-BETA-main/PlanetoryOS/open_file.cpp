#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    string filename;
    cout << "Insert file name: ";
    cin >> filename;

    ifstream f(filename);

    if (f.is_open())
        cout << f.rdbuf();
}