#include <iostream>
#include <stdlib.h>
using namespace std;

int main() 
{
    int bin[100], i=0, x, num, length;
    printf("Enter number : ");
    scanf("%d",&num);
    printf("\n%d in binary is = ", num);
    if(num<=0)
    {
        printf("\nIt has to be greater than 0");
    }
    while(num>0) 
    {     
        bin[i]=num%2;
        num=num/2;
        i++;
    } 
    length = i;
    for(x=length-1;x>=0;x--)
    {
        printf("%d",bin[x]);
    }
    printf("\n\n");
    return 0;
}