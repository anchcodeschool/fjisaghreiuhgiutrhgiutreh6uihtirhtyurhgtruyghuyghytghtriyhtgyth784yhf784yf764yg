#include <iostream>
using namespace std;

int main()
{
    float interest , money, total, compound;
    int year, j;
    printf("Enter interest rate \n");
    scanf("%f", &interest);
    printf("compound interest \n");
    printf("Enter money you have : \n");
    scanf("%f", &money);
    printf("Enter years : \n");
    scanf("%d", &year);
    if (year > 0 && year < 100 && money >0 && money < 1000000) {
        for (j = 1; j <= year; j++)
        {
            compound = money * interest / 100;
            total = money + compound;
            money = total;
            printf("After year %d, you will have $%f\n", j, total);
        }
    }
    else {
        printf("Enter valid input\n");
    }
    return 0;
}
