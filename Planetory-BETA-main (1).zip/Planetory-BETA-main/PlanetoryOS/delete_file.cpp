#include<iostream>

using namespace std;
int main()
{
    int status;
    char fileName[20];
    cout<<"Enter the name of file you want to delete: ";
    cin>>fileName;
    status = remove(fileName);
    if(status==0)
        cout<<"\nFile Deleted Successfully!";
    else
        cout<<"\nError Occurred!";
    cout<<endl;
    return 0;
}