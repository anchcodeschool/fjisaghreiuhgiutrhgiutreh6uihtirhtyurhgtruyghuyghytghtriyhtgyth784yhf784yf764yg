#include <string>
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;

int main()
{

    string line;
    vector<string> v; // creating a vector
    string filename;

    while(getline(cin, line))
    {
        if(line.empty() && !v.empty() && v.back().empty()) 
        {
            v.pop_back(); // remove the last empty line
            break;
        }
        v.push_back(line); 
    }

    cout << "Save as filename: ";
    cin >> filename;
    std::ofstream outFile(filename);
    // the important part
    for (const auto &e : v) outFile << e << "\n";

    return 0;
}