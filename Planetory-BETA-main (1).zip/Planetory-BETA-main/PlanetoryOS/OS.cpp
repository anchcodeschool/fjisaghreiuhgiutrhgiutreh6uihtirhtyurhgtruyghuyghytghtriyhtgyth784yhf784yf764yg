#include <iostream>
#include <fstream>
using namespace std;

void ver() {
        cout << "Planetory BETA\n\n";
}

void runProgram(string exeName)
{
    try
    {
        const char * c = exeName.c_str();
        system(c);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
}

int main() {
    string cmd;
    string exeName;
    bool contRun = true;

    cout << "Planetory BETA\n";
    cout << "Copyright © 2022 Planetory\n\n";

    while(contRun)
    {
        cin >> cmd;
        cout << "\n";

        if (cmd == "ver")
            ver();
        else if(cmd == "exit") {
            char dummy[10];
            cout << "Exiting Planetory...\n";
            cout << "Press Enter to continue...\n";
            cin.getline(dummy, 10);
            cin.getline(dummy, 10);
            contRun = false;
        }
        else
        {
            exeName = cmd.substr(cmd.find("/")+1, cmd.length());
            runProgram(exeName + ".exe");
            cout << "\n";
        }
    }
    

    return 0;

}