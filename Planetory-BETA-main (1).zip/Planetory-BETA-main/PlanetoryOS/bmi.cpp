#include <iostream>
using namespace std;

int main()
{
    float weight, height, bmi, h;
    char purple[] = "You need more fuel";
    char green[] = "You are in perfect condition";
    char yellow[] = "You are overweight and you need more exercise";
    printf("Enter your weight in kgs: ");
    scanf("%f",&weight);
    printf("Enter your height in cm: ");
    scanf("%f",&h);
    height = h/100;
    bmi = weight /(height*height);
    printf("\n Body Mass Index is %f\n ",bmi);
    if (bmi<18.5)
    {
        printf("Result : %s\n\n", purple);
    }else if(bmi>18.5 && bmi<25)
    {
        printf("Result : %s\n\n", green);
    }else if(bmi>25)
    {
        printf("Result : %s\n\n", yellow);
    }
}
