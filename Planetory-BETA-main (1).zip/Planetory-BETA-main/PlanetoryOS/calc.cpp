#include <iostream>
using namespace std;

int main() {
    int firstNum;
    int secondNum;
    char op;
    double answer;

    cout << "Calculator.exe ver 1.0.0\n";
    cout << "Copyright © 2022 Techno\n\n";

    cout << "Type your first number: ";
    cin >> firstNum;

    cout << "Type your second number: ";
    cin >> secondNum;

    cout << "Insert operator: ";
    cin >> op;

    if (op == '+') {
        answer = firstNum + secondNum;
    }
    else if (op == '-') {
        answer = firstNum - secondNum;
    }
    else if (op == '/') {
        answer = (double)firstNum / (double)secondNum;
    }
    else if (op == '*') {
        answer = firstNum * secondNum;
    }

    cout << "The answer is: " << answer << "\n\n";
}